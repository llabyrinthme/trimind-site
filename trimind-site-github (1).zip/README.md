# TRIMIND Site

Homepage inspirada no design de Elaine Ourives, com carrossel, barra dourada e ícones.