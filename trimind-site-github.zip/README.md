# trimind-site

Site oficial TRIMIND com integração GitHub + Netlify.